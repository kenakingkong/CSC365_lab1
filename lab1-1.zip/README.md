# CSC365 Lab 1

## Compile Instruction: None

## Run Instruction: **python ./studentSearch.py**
  * Note: use python, python3, py, py -3 depending on your version of python
